import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Footer from '@/components/Footer';
import { About, Services, Projects, Experience, Skills, Contact } from '@/components/Sections';

export default function Home(){return <><Navbar/><main><Hero/><About/><Services/><Projects/><Experience/><Skills/><Contact/></main><Footer/></>}
