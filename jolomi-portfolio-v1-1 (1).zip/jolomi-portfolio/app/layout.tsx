import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Jolomi Dudu | Software Engineer',
  description: 'Portfolio of Jolomi Dudu — software engineer building mobile apps, web platforms and backend systems.',
  metadataBase: new URL('https://jolomidudu.vercel.app')
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body className="noise">{children}</body></html>;
}
