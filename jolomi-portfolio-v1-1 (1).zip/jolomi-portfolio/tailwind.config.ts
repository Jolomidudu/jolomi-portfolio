import type { Config } from 'tailwindcss';
const config: Config = {
  content: ['./app/**/*.{js,ts,jsx,tsx,mdx}','./components/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: { extend: { colors: { ink:'#07090d', panel:'#0d1117', teal:'#00a99d', cyan:'#38bdf8' }, boxShadow: { glow:'0 0 80px rgba(0,169,157,.18)' } } },
  plugins: []
};
export default config;
