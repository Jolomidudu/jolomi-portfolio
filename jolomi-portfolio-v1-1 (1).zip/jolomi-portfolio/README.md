# Jolomi Dudu Portfolio

A premium personal portfolio built with Next.js, TypeScript, Tailwind CSS and Framer Motion.

## Run locally

```bash
npm install
npm run dev
```

Then open http://localhost:3000.

## Deploy to Vercel

Push the repository to GitHub, import it into Vercel, and use the default Next.js settings. No environment variables are required for this first version.

## Assets

- `public/images/jolomi.jpg` — supplied professional photo
- `public/resume.pdf` — supplied resume
